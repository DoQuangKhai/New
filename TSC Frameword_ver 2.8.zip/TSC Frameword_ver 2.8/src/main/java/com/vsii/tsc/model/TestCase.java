package com.vsii.tsc.model;

import java.util.List;

public class TestCase {
	private String tcID;
	private String tcLct;
	private String tcDesc;
	private String tcPrec;
	private String tcStep;
	private String tcExpt;
	private String tcPri;
	private String tcTestData;
	private List<TestResult> testResultList;
	
	
	
	public String getTcTestData() {
		return tcTestData;
	}
	public void setTcTestData(String tcTestData) {
		this.tcTestData = tcTestData;
	}
	public String getTcLct() {
		return tcLct;
	}
	public void setTcLct(String tcLct) {
		this.tcLct = tcLct;
	}
	public String getTcPri() {
		return tcPri;
	}
	public void setTcPri(String tcPri) {
		this.tcPri = tcPri;
	}
	public String getTcID() {
		return tcID;
	}
	public void setTcID(String tcID) {
		this.tcID = tcID;
	}
	public String getTcDesc() {
		return tcDesc;
	}
	public void setTcDesc(String tcDesc) {
		this.tcDesc = tcDesc;
	}
	public String getTcPrec() {
		return tcPrec;
	}
	public void setTcPrec(String tcPrec) {
		this.tcPrec = tcPrec;
	}
	public String getTcStep() {
		return tcStep;
	}
	public void setTcStep(String tcStep) {
		this.tcStep = tcStep;
	}
	public String getTcExpt() {
		return tcExpt;
	}
	public void setTcExpt(String tcExpt) {
		this.tcExpt = tcExpt;
	}
	/**
	 * @return the testResultList
	 */
	public List<TestResult> getTestResultList() {
		return testResultList;
	}
	/**
	 * @param testResultList the testResultList to set
	 */
	public void setTestResultList(List<TestResult> testResultList) {
		this.testResultList = testResultList;
	}
	
	
	

	
	
	

}
