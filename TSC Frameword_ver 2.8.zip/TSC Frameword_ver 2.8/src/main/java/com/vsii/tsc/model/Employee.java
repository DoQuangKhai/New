package com.vsii.tsc.model;

public class Employee
{
    private String screeningDate;
    private String dateSubmitted;
    private String screeningCode;
    private String techName;
    private String position;
    private String techID;
    private boolean isFloatIn;
    private String DriveTimeToSite;
    private String Setup;
    private String Scan;
    private String Teardown;
    private String DriveTimeFromSite;
    private String Lunch;
    private String AdditionalHours;
    private String TotalHours;
    private String ApprovalStatus;
    
    //TODO: Beanshell
    
    public String getScreeningCode()
    {
        return screeningCode;
    }
    public void setScreeningCode(String screeningCode)
    {
        this.screeningCode = screeningCode;
    }
    public String getTechName()
    {
        return techName;
    }
    public void setTechName(String techName)
    {
        this.techName = techName;
    }
    public String getPosition()
    {
        return position;
    }
    public void setPosition(String position)
    {
        this.position = position;
    }
    public String getTechID()
    {
        return techID;
    }
    public void setTechID(String techID)
    {
        this.techID = techID;
    }
    public boolean isFloatIn()
    {
        return isFloatIn;
    }
    public void setFloatIn(boolean isFloatIn)
    {
        this.isFloatIn = isFloatIn;
    }
    public String getDriveTimeToSite()
    {
        return DriveTimeToSite;
    }
    public void setDriveTimeToSite(String driveTimeToSite)
    {
        DriveTimeToSite = driveTimeToSite;
    }
    public String getSetup()
    {
        return Setup;
    }
    public void setSetup(String setup)
    {
        Setup = setup;
    }
    public String getScan()
    {
        return Scan;
    }
    public void setScan(String scan)
    {
        Scan = scan;
    }
    public String getTeardown()
    {
        return Teardown;
    }
    public void setTeardown(String teardown)
    {
        Teardown = teardown;
    }
    public String getDriveTimeFromSite()
    {
        return DriveTimeFromSite;
    }
    public void setDriveTimeFromSite(String driveTimeFromSite)
    {
        DriveTimeFromSite = driveTimeFromSite;
    }
    public String getLunch()
    {
        return Lunch;
    }
    public void setLunch(String lunch)
    {
        Lunch = lunch;
    }
    public String getAdditionalHours()
    {
        return AdditionalHours;
    }
    public void setAdditionalHours(String additionalHours)
    {
        AdditionalHours = additionalHours;
    }
    public String getTotalHours()
    {
        return TotalHours;
    }
    public void setTotalHours(String totalHours)
    {
        TotalHours = totalHours;
    }
    public String getApprovalStatus()
    {
        return ApprovalStatus;
    }
    public void setApprovalStatus(String approvalStatus)
    {
        ApprovalStatus = approvalStatus;
    }
    public String getScreeningDate()
    {
        return screeningDate;
    }
    public void setScreeningDate(String screeningDate)
    {
        this.screeningDate = screeningDate;
    }
    public String getDateSubmitted()
    {
        return dateSubmitted;
    }
    public void setDateSubmitted(String dateSubmitted)
    {
        this.dateSubmitted = dateSubmitted;
    }
    

}
