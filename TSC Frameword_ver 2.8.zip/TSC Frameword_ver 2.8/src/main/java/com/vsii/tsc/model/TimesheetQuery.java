package com.vsii.tsc.model;

import java.util.Date;
import java.util.List;

public class TimesheetQuery {
	
	public String TechName;
    public String TeamCode;
    public String ScreeningCode;
    public Date FromDate;
    public Date ToDate;
    public int PageNumber;
    public String OrderColumnName;
    public String SortType;
    public List<String> StatusSelection;

}
