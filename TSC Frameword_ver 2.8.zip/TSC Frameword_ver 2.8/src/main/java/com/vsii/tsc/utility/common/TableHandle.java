package com.vsii.tsc.utility.common;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TableHandle
{
    public static final int TYPE_LINK = 1;
    public static final int TYPE_INPUT = 2;

    /**
     * 
     * <p>
     * This method will perform click to a button in a table, this method does work if in the cell that contain button
     * want to click have 2 or more button
     * </p>
     *
     * @since Jul 11, 2017
     * @author thanhvc
     * @param driver
     * @param textToCompare
     *            text in the row you need to click to Button (should in case sensitive)
     * @param buttonType
     *            the are 2 type of button in table are link and input, using variable of this class to declare your
     *            button type (ex: TableHandle.TYPE_LINK or TableHandle.TYPE_INPUT)
     *
     */
    public static void clickToSingleButton(WebDriver driver, String textToCompare, int buttonType)
    {
        String xpath = "";
        switch (buttonType)
        {
            case 1: //Button is a linktext 
                xpath =
                    "//td[normalize-space()='" + textToCompare + "']/following-sibling::td[a]/descendant::*[last()]";
                break;
            case 2: //Button is a input element
                xpath = "//td[normalize-space()='" + textToCompare
                    + "']/following-sibling::td[input]/descendant::*[last()]";
                break;
            default:
                System.out.println("No button type is declared");
                break;
        }
        driver.findElement(By.xpath(xpath)).click();
    }

    /**
     * 
     * <p>
     * This method used for click to a button in a table based on table position, row position and column (contain
     * button)'s position, this method does work if in the cell that contain button have 2 or more buttons inside it
     * </p>
     *
     * @since Jul 11, 2017
     * @author thanhvc
     * @param driver
     * @param tablePosition
     *            if in current displayed page have 1 table only, then table position is 1
     * @param rowPosition
     *            position of the row contain the button you want to click
     * @param columnPosition
     *            the column that contain button want to click (column should have 1 button only)
     *
     */
    public static void clickToSingleButton(WebDriver driver, int tablePosition, int rowPosition, int columnPosition)
    {
        String xpath = "//table[" + tablePosition + "]/tbody/tr[" + rowPosition + "]/td[" + columnPosition
            + "]/descendant-or-self::*[last()]";
        driver.findElement(By.xpath(xpath)).click();
    }

    /**
     * 
     * <p>
     * This method used for click to a button based on a text displayed in the row and text displayed on button you want
     * to click to
     * </p>
     *
     * @since Jul 11, 2017
     * @author thanhvc
     * @param driver
     * @param textToCompare
     *            text in the row you need to click to Button (should in case sensitive)
     * @param buttonText
     *            text (value) displayed on the button
     *
     */
    public static void clickToButtonText(WebDriver driver, String textToCompare, String buttonText)
    {
        String xpath = "//td[normalize-space()='" + textToCompare
            + "']/following-sibling::td/descendant-or-self::*[last()][normalize-space()='" + buttonText + "']";
        driver.findElement(By.xpath(xpath)).click();
    }

    /**
     * 
     * <p>
     * Return a text value inside a column that follow column contain the text used for define the row
     * </p>
     *
     * @since Jul 11, 2017
     * @author thanhvc
     * @param driver
     * @param textToCompare
     *            the text you using for define which row you want to get value
     * @param position
     *            position of column contain value you want to get, Note that after column contain textToCompare, column
     *            position is 1, the next one is 2...
     * @return text value inside a column
     *
     */
    public static String getFollowingColumnValue(WebDriver driver, String textToCompare, int position)
    {
        String xpath = "//td[normalize-space()='" + textToCompare + "']/following-sibling::td[" + position
            + "]/descendant-or-self::*[last()]";
        return driver.findElement(By.xpath(xpath)).getText().trim();
    }

    /**
     * 
     * <p>
     * Return a text value inside a column that preceding column contain the text used for define the row
     * </p>
     *
     * @since Jul 11, 2017
     * @author thanhvc
     * @param driver
     * @param textToCompare
     *            the text you using for define which row you want to get value
     * @param position
     *            position of column contain value you want to get, Note that before column contain textToCompare,
     *            column position is 1, the next one is 2...
     * @return text value inside a column
     *
     */
    public static String getPrecedingColumnValue(WebDriver driver, String textToCompare, int position)
    {
        String xpath = "//td[normalize-space()='" + textToCompare + "']/preceding-sibling::td[" + position
            + "]/descendant-or-self::*[last()]";
        return driver.findElement(By.xpath(xpath)).getText().trim();
    }

    /**
     * 
     * <p>
     * Get all values in all rows for a specific column
     * </p>
     *
     * @since Jul 11, 2017
     * @author thanhvc
     * @param driver
     * @param tablePosition
     *            if in current displayed page have 1 table only, then table position is 1...
     * @param columnPosition
     *            position of column you want to get all values for all rows
     * @return a list of values of all rows for a fixed column position in current page
     *
     */
    public static List<String> getAllColumnValuesInCurrentPage(WebDriver driver, int tablePosition, int columnPosition)
    {
        List<WebElement> el = new ArrayList<>();
        List<String> values = new ArrayList<>();
        String xpath =
            "//table[" + tablePosition + "]/tbody/tr/td[" + columnPosition + "]/descendant-or-self::*[last()]";
        el = driver.findElements(By.xpath(xpath));
        for (WebElement e : el)
        {
            values.add(e.getText().trim());
        }
        return values;
    }

    /**
     * 
     * <p>
     * Get column data based on its header
     * </p>
     *
     * @since Jul 13, 2017
     * @author thanhvc
     * @param driver
     * @param tablePosition
     *            if in current displayed page have 1 table only, then table position is 1...
     * @param columnHeader
     *            header's text of column you want to get data
     * @return A list of data of a specific column based on its header
     *
     */
    public static List<String> getAllColumnValuesInCurrentPage(WebDriver driver, int tablePosition, String columnHeader)
    {
        List<String> values = new ArrayList<>();
        List<WebElement> cells = new ArrayList<>();
        int colPosition = getColumnPositionBasedOnItsHeader(driver, tablePosition, columnHeader);
        String xpathCell =
            "//table[" + tablePosition + "]/tbody/tr/td[" + colPosition + "]/descendant-or-self::*[last()]";
        cells = driver.findElements(By.xpath(xpathCell));
        for (WebElement cell : cells)
        {
            values.add(cell.getText().trim());
        }
        return values;
    }

    /**
     * 
     * <p>
     * Get all table data in current page and store them in a LinkedHashMap with keys is name of table header
     * </p>
     *
     * @since Jul 13, 2017
     * @author thanhvc
     * @param driver
     * @param tablePosition
     *            if in current displayed page have 1 table only, then table position is 1...
     * @return A LinkedHashMap store all table data for current displayed page
     *
     */
    public static LinkedHashMap<String, List<String>> getAllTableDataInCurrentPage(WebDriver driver, int tablePosition)
    {
        LinkedHashMap<String, List<String>> hm = new LinkedHashMap<>();
        String xpathHeaderColNum = "//table[" + tablePosition + "]/thead/tr/td";
        int noOfCol = driver.findElements(By.xpath(xpathHeaderColNum)).size();
        List<String> headers = getHeaders(driver, tablePosition);
        for (int i = 0; i < noOfCol; i++)
        {
            hm.put(headers.get(i), getAllColumnValuesInCurrentPage(driver, tablePosition, i + 1));
        }
        return hm;
    }

    /**
     * 
     * <p>
     * Get column position based on its header
     * </p>
     * 
     * @since Jul 13, 2017
     * @author thanhvc
     * @param driver
     * @param tablePosition
     *            if in current displayed page have 1 table only, then table position is 1...
     * @param columnHeader
     *            header's text of column you want to position
     * @return A position of column based on its header (note: the lowest position always = 1)
     *
     */
    public static int getColumnPositionBasedOnItsHeader(WebDriver driver, int tablePosition, String columnHeader)
    {
        int colPosition = 0;
        String xpathHeaderColNum = "//table[" + tablePosition + "]/thead/tr/td";
        int noOfCol = driver.findElements(By.xpath(xpathHeaderColNum)).size();
        HeaderLoop: for (int i = 1; i <= noOfCol; i++)
        {
            List<WebElement> el = new ArrayList<>();
            String xpathHeader = "//table[" + tablePosition + "]/thead/tr/td[" + i + "]/descendant-or-self::*";
            el = driver.findElements(By.xpath(xpathHeader));
            for (WebElement e : el)
            {
                if (e.getText().trim().equals(columnHeader))
                {
                    colPosition = i;
                    break HeaderLoop;
                }
            }
        }
        return colPosition;
    }

    /**
     * 
     * <p>
     * Get number of row data in current displayed page
     * </p>
     *
     * @since Jul 13, 2017
     * @author thanhvc
     * @param driver
     * @param tablePosition
     *            if in current displayed page have 1 table only, then table position is 1...
     * @return number of row data in current displayed page
     *
     */
    public static int getTotalNumberOfRowInCurrentPage(WebDriver driver, int tablePosition)
    {
        String xpath = "//table[" + tablePosition + "]/tbody/tr";
        return driver.findElements(By.xpath(xpath)).size();
    }

    /**
     * 
     * <p>
     * Get all headers text of table
     * </p>
     *
     * @since Jul 13, 2017
     * @author thanhvc
     * @param driver
     * @param tablePosition
     *            if in current displayed page have 1 table only, then table position is 1...
     * @return A list of header in text (if header doesn't have text, then it auto has name is Empty_Header_<increament
     *         number>
     *
     */
    public static List<String> getHeaders(WebDriver driver, int tablePosition)
    {
        List<String> headers = new ArrayList<>();
        String xpathHeaderColNum = "//table[" + tablePosition + "]/thead/tr/td";
        int noOfCol = driver.findElements(By.xpath(xpathHeaderColNum)).size();
        int t = 1;
        for (int i = 1; i <= noOfCol; i++)
        {
            String header = "";
            String xpathHeader = "//table[" + tablePosition + "]/thead/tr/td[" + i + "]/descendant-or-self::*[last()]";
            header = driver.findElement(By.xpath(xpathHeader)).getText().trim();
            if (header.isEmpty())
            {
                header = "Empty_Header_" + t;
                t++;
            }
            headers.add(header);
        }
        return headers;
    }
}
