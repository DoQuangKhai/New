package com.vsii.tsc.utility.io;

import java.io.File;
import java.nio.charset.Charset;
import java.util.List;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.vsii.tsc.model.TestCase;
import com.vsii.tsc.model.TestResult;

public class ReportHandle {
	/**
	 * @param htmlName
	 * @param tcList
	 * @return HTML Report
	 */
	public static void buildHTMLReport(String htmlName, List<TestCase> tcList) {
		ExtentReports exReport = new ExtentReports(htmlName, true);
//		exReport.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
		ExtentTest exTest = null;
		for (TestCase testCase : tcList) {
			for (TestResult testResult : testCase.getTestResultList()) {
				exTest = exReport.startTest(testResult.getSheetName() + "/" + testCase.getTcID())
						.assignCategory(testResult.getBrowser().toUpperCase());
				switch (LogStatus.valueOf(testResult.getResult().toUpperCase().substring(0, 4))) {
				case PASS:
					exTest.log(LogStatus.PASS, "Test Purpose", testCase.getTcDesc());
					exTest.log(LogStatus.PASS, "Precondition", testCase.getTcPrec());
					exTest.log(LogStatus.PASS, "Steps", testCase.getTcStep());
					exTest.log(LogStatus.PASS, "Expected result", testCase.getTcExpt());
					exTest.log(LogStatus.PASS, "Image",
							String.valueOf(exTest.addScreenCapture(testResult.getImagePath())));
					exTest.log(LogStatus.PASS, "Status", "Test Passed");
					break;
				case FAIL:
					exTest.log(LogStatus.FAIL, "Test Purpose", testCase.getTcDesc());
					exTest.log(LogStatus.FAIL, "Precondition", testCase.getTcPrec());
					exTest.log(LogStatus.FAIL, "Steps", testCase.getTcStep());
					exTest.log(LogStatus.FAIL, "Expected result", testCase.getTcExpt());
					exTest.log(LogStatus.FAIL, "Image",
							String.valueOf(exTest.addScreenCapture(testResult.getImagePath())));
					exTest.log(LogStatus.FAIL, "Status", "Test Failed: " + testResult.getErrMessage());
					break;
				case SKIP:
					exTest.log(LogStatus.SKIP, "Test Purpose", testCase.getTcDesc());
					exTest.log(LogStatus.SKIP, "Precondition", testCase.getTcPrec());
					exTest.log(LogStatus.SKIP, "Steps", testCase.getTcStep());
					exTest.log(LogStatus.SKIP, "Expected result", testCase.getTcExpt());
					exTest.log(LogStatus.SKIP, "Image",
							String.valueOf(exTest.addScreenCapture(testResult.getImagePath())));
					exTest.log(LogStatus.SKIP, "Status", "Test Skipped: " + testResult.getErrMessage());
					break;
				default:
					exTest.log(LogStatus.INFO, "Test Purpose", testCase.getTcDesc());
					exTest.log(LogStatus.INFO, "Precondition", testCase.getTcPrec());
					exTest.log(LogStatus.INFO, "Steps", testCase.getTcStep());
					exTest.log(LogStatus.INFO, "Expected result", testCase.getTcExpt());
					exTest.log(LogStatus.INFO, "Image",
							String.valueOf(exTest.addScreenCapture(testResult.getImagePath())));
					exTest.log(LogStatus.INFO, "Status", "Unknow: " + testResult.getErrMessage());
					break;
				}
				exReport.endTest(exTest);
			}
		}
		exReport.flush();
		exReport.close();
		System.out.println("Completed generate HTML Report");
	}
}