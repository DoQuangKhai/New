package com.vsii.tsc.utility.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.vsii.tcbs.testcase.TestBase;
import com.vsii.tsc.model.TestCase;
import com.vsii.tsc.model.TestResult;
import com.vsii.tsc.utility.datetime.DateTime;

public class ExcelHandle {

    static FileInputStream file;
    static XSSFWorkbook workbook;
    static XSSFSheet sheet;
    static XSSFRow row;
    static Cell cell;
    private static Properties props = new Properties();

    // Use for get TC Table template
    public static TestCase testcase;
    public static List<TestResult> resultOfATestCase;

    // Use to copy file
    File source;
    File dest;

    // -----------------------------------------------------------------------------------------------------------------------------
    /*
     * Read test data from table in excel file
     */
    public static String[][] getTable(String filePath, String sheetName, String tableName) {

        FileInputStream fileTable = null;
        XSSFWorkbook workbookTable = null;
        XSSFSheet sheetTable;
        XSSFRow rowTable;
        Cell cellTable;

        // Use for getTable() method
        String testData[][];

        String tagName = null;
        List<Cell> tagList = new ArrayList<Cell>();
        int startRow = 0;
        int startCol = 0;
        int endRow = 0;
        int endCol = 0;

        // Open file
        try {
            fileTable = new FileInputStream(filePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Define workbook
        try {
            workbookTable = new XSSFWorkbook(fileTable);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Define sheet
        sheetTable = workbookTable.getSheet(sheetName);

        // Iterate through each row
        Iterator<Row> rowIterator = sheetTable.iterator();
        while (rowIterator.hasNext()) {
            rowTable = (XSSFRow) rowIterator.next();
            Iterator<Cell> cellIterator = rowTable.iterator();
            while (cellIterator.hasNext()) {
                cellTable = cellIterator.next();
                // Check the cell type and format
                switch (cellTable.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                    tagName = cellTable.getStringCellValue();
                    // case Cell.CELL_TYPE_NUMERIC:
                    // = String.valueOf(cell.getNumericCellValue());
                    if (tagName.equalsIgnoreCase(tableName)) {
                        tagList.add(cellTable);
                    }
                }

               
            }
        }
        // Identify table
        if (tagList.size() == 2) {
            startRow = tagList.get(0).getRowIndex() + 1;
            // System.out.println(startRow);
            startCol = tagList.get(0).getColumnIndex() + 1;
            // System.out.println(startCol);
            endRow = tagList.get(1).getRowIndex() - 1;
            // System.out.println(endRow);
            endCol = tagList.get(1).getColumnIndex() - 1;
            // System.out.println(endCol);
        } else
            System.out.println("Wrong table");

        testData = new String[endRow - startRow + 1][endCol - startCol + 1];

        int x = 0;
        for (int i = startRow; i <= endRow; i++, x++) {
            int y = 0;
            for (int j = startCol; j <= endCol; j++, y++) {
                rowTable = sheetTable.getRow(i);
                testData[x][y] = rowTable.getCell(j).toString();
                System.out.println(testData[x][y]);
            }
        }
        return testData;
    }

    // -----------------------------------------------------------------------------------------------------------------------------
    /*
     * copy file
     */
    public static void copyFile(File source, File dest) {

        try {
            FileUtils.copyFile(source, dest);
            System.out.println("Success to copy data from Test Case File to Test Result File");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized static void writeResultToExcel(List<TestResult> listResult, String resultFile) { 
        // Load properties
        try {

            InputStream inStream = new FileInputStream("./properties/config.properties");
            props.load(inStream);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Load excel result file
        try {
            file = new FileInputStream(resultFile);
            synchronized (file) {
                workbook = new XSSFWorkbook(file);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Get number of sheet
        int noOfSheet = workbook.getNumberOfSheets();
        // Loop for each sheet
        for (int i = 0; i < noOfSheet; i++) {
            String sheetName = null;
            int lastRowNum = 0;
            String tcID = null;

            sheet = workbook.getSheetAt(i);
            sheetName = sheet.getSheetName();
            lastRowNum = sheet.getLastRowNum();

            // Loop for each row
            for (int j = Integer.parseInt(props.getProperty("resultRow")); j <= lastRowNum; j++) {
                tcID = sheet.getRow(j).getCell(0).getStringCellValue();
                testcase = new TestCase();
                testcase.setTcID(tcID);
                testcase.setTcDesc(
                        sheet.getRow(j).getCell(Integer.parseInt(props.getProperty("tcDescCol"))).getStringCellValue());
                testcase.setTcExpt(
                        sheet.getRow(j).getCell(Integer.parseInt(props.getProperty("tcExptCol"))).getStringCellValue());
                testcase.setTcPrec(
                        sheet.getRow(j).getCell(Integer.parseInt(props.getProperty("tcPreCol"))).getStringCellValue());
                testcase.setTcStep(
                        sheet.getRow(j).getCell(Integer.parseInt(props.getProperty("tcStepCol"))).getStringCellValue());
                resultOfATestCase = new ArrayList<TestResult>();
                // Loop for the list Result
                for (int t = 0; t < listResult.size(); t++) {
                    if (listResult.get(t).getTcID().equals(tcID)) {
                        // If data in list match, then write to Excel (firefox
                        // result)
                        if (listResult.get(t).getBrowser().equalsIgnoreCase("firefox")
                                && listResult.get(t).getSheetName().equals(sheetName)) {
                            resultOfATestCase.add(listResult.get(t));
                            setResultValueForWorkBook(listResult, sheetName, tcID, sheet, t, j, "firefox",
                                    Integer.parseInt(props.getProperty("firefoxResult")),
                                    Integer.parseInt(props.getProperty("firefoxNotes")));
                        }

                        // If data in list match, then write to Excel (chrome
                        // result)
                        if (listResult.get(t).getBrowser().equalsIgnoreCase("chrome")
                                && listResult.get(t).getSheetName().equals(sheetName)) {
                            resultOfATestCase.add(listResult.get(t));
                            setResultValueForWorkBook(listResult, sheetName, tcID, sheet, t, j, "chrome",
                                    Integer.parseInt(props.getProperty("chromeResult")),
                                    Integer.parseInt(props.getProperty("chromeNotes")));
                        }

                        // If data in list match, then write to Excel (IE
                        // result)
                        if (listResult.get(t).getBrowser().equalsIgnoreCase("ie")
                                && listResult.get(t).getSheetName().equals(sheetName)) {
                            resultOfATestCase.add(listResult.get(t));
                            setResultValueForWorkBook(listResult, sheetName, tcID, sheet, t, j, "ie",
                                    Integer.parseInt(props.getProperty("ieResult")),
                                    Integer.parseInt(props.getProperty("ieNotes")));
                        }
                    }
                }
                testcase.setTestResultList(resultOfATestCase);
                if (resultOfATestCase.size() > 0) {
                    TestBase.tcListBase.add(testcase);
                }
            }
        }

        try {
            FileOutputStream fileOut = new FileOutputStream(resultFile);
            workbook.write(fileOut);
            workbook.close();
            fileOut.close();
            file.close();
            System.out.println("Complete generate excel report");
        } catch (Exception e) {
            //
        }

    }

    private static void setResultValueForWorkBook(List<TestResult> listResult, String sheetName, String tcID,
            XSSFSheet sheet, int t, int j, String browserName, int resultIndex, int noteIndex) {
        String resultText = "";

        // Create new CellStype object for each row
        XSSFCellStyle myStyle = workbook.createCellStyle();

        myStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        myStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
        myStyle.setBorderTop((short) 1);
        myStyle.setBorderBottom((short) 1);
        myStyle.setBorderLeft((short) 1);
        myStyle.setBorderRight((short) 1);
        myStyle.setVerticalAlignment(VerticalAlignment.CENTER);

        // If data in list match, then write to Excel (firefox result)
        if (listResult.get(t).getSheetName().equals(sheetName) && listResult.get(t).getTcID().equals(tcID)
                && listResult.get(t).getBrowser().equalsIgnoreCase(browserName)
                && (sheet.getRow(j).getCell(resultIndex).getStringCellValue().isEmpty()
                || !sheet.getRow(j).getCell(resultIndex).getStringCellValue().equalsIgnoreCase("failed"))) {
            resultText = listResult.get(t).getResult();

            if (resultText.equalsIgnoreCase("passed")) {
                myStyle.setFillForegroundColor(new XSSFColor(java.awt.Color.GREEN));
            } else if (resultText.equalsIgnoreCase("failed")) {
                myStyle.setFillForegroundColor(new XSSFColor(java.awt.Color.RED));
            } else if (resultText.equalsIgnoreCase("skipped")) {
                myStyle.setFillForegroundColor(new XSSFColor(java.awt.Color.YELLOW));
            }

            sheet.getRow(j).getCell(resultIndex).setCellValue(listResult.get(t).getResult().toUpperCase());

            sheet.getRow(j).getCell(resultIndex).setCellStyle(myStyle);

            sheet.getRow(j).getCell(noteIndex).setCellValue("- " + listResult.get(t).getErrMessage());
        } else if (listResult.get(t).getSheetName().equals(sheetName) && listResult.get(t).getTcID().equals(tcID)
                && listResult.get(t).getBrowser().equalsIgnoreCase(browserName)
                && sheet.getRow(j).getCell(resultIndex).getStringCellValue().equalsIgnoreCase("failed")) {
            // Get previous message in case that test case is failed before
            String previousMsg = sheet.getRow(j).getCell(noteIndex).getStringCellValue();

            // Add more error message to notes field
            sheet.getRow(j).getCell(noteIndex)
                    .setCellValue(previousMsg + "\n" + "- " + listResult.get(t).getErrMessage());

        }
    }

    public static String createEmptyExcelFile(String fileName) {
        // Load properties
        try {

            InputStream inStream = new FileInputStream("./properties/config.properties");
            props.load(inStream);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Get directory of result file (excel format0
        String dir = props.getProperty("resultpath");

        // Create a full path of result file
        String path = dir + fileName + "_" + DateTime.createDateText("yyyyMMddHHmmss") + ".xlsx";

        // Create physic file
        File file = new File(path);

        try {
            file.createNewFile();
            System.out.println("Success to create Test Result File");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error: cannot create Test Result File");
        }

        // Return a full path of result file
        return path;
    }

}
