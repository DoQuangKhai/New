/*
 * FILENAME
 *     ReadExcel.java
 *
 * FILE LOCATION
 *     $Source$
 *
 * VERSION
 *     $Id$
 *         @version       $Revision$
 *         Check-Out Tag: $Name$
 *         Locked By:     $Lockers$
 *
 * FORMATTING NOTES
 *     * Lines should be limited to 78 characters.
 *     * Files should contain no tabs.
 *     * Indent code using four-character increments.
 *
 * COPYRIGHT
 *     Copyright (C) 2007 Genix Ventures Pty. Ltd. All rights reserved.
 *     This software is the confidential and proprietary information of
 *     Genix Ventures ("Confidential Information"). You shall not
 *     disclose such Confidential Information and shall use it only in
 *     accordance with the terms of the license agreement you entered into
 *     with Genix Ventures.
 */

package com.vsii.tsc.utility.action;

import java.util.List;
import java.util.Properties;

import org.testng.ITestResult;

import com.vsii.tcbs.testcase.TestBase;
import com.vsii.tsc.model.TestResult;

public class Synchronizer
{
    private static final Synchronizer syncRs = new Synchronizer();

    private Synchronizer()
    {
        super();
    }

    public static Synchronizer getInstance()
    {
        return syncRs;
    }

    //Synchronize write data to list result in case multiple thread (browser) run at the same time (paralel)
    //This method only effect at aftermethod, when the test is done
    public synchronized void getTestResult(ITestResult result, TestResult objTestResult,
        List<TestResult> listResultStored, Properties p) throws Exception
    {
        //Create new Test Result object for this method
        objTestResult = new TestResult();
        
        //Declare string variable to store error message (or failed reason), if have
        String errorMessage = "";

        //Get current browser
        String curBrowser = result.getTestContext().getCurrentXmlTest().getParameter("browser");
        
        //Get sheet name 
        String sheetName = result.getTestContext().getCurrentXmlTest().getParameter("sheetName");

        //Get test result
        String currentTestResult = CommonOperations.getMethodTestResult(result);

        //Take picture
        CommonOperations.takePicture(curBrowser, result.getMethod().getMethodName(),
            currentTestResult);

        //Get image name
        String currentImageName = TestBase.imageName;

        //Store result in object Test Result
        //Store running browser name
        objTestResult.setBrowser(curBrowser);
        
        //Store sheet name
        objTestResult.setSheetName(sheetName);

        //Store method name (aka test case ID)
        objTestResult.setTcID(result.getMethod().getMethodName());

        //Store test result
        objTestResult.setResult(currentTestResult);

        //Store error (failed) message (if have)
        try
        {
            errorMessage = result.getThrowable().getMessage();
        }
        catch (Exception e)
        {
            //Nothing to show here
        }
        objTestResult.setErrMessage(errorMessage);

        //Store picture path
        objTestResult.setImagePath("."+p.getProperty("imagePath") + currentImageName + ".jpg");

        //Put object TestResult to list 
        listResultStored.add(objTestResult);
    }
}
