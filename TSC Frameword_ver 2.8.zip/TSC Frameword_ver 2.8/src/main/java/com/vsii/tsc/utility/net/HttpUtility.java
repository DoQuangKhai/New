package com.vsii.tsc.utility.net;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.Scanner;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;
import com.google.gson.Gson;
import java.util.Base64;

public class HttpUtility {

	public String GetResponse(String address){
		String  response = "";
		try {
			URL url = new URL(address);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			Scanner scan = new Scanner(url.openStream());
			response = new String();
			while (scan.hasNext())
				response += scan.nextLine();
			scan.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return response;
	}
	
	public void postJson(Object data, String urlString){
		HttpClient httpClient = HttpClientBuilder.create().build(); //Use this instead 
		try {
			Gson gson = new Gson();
			String json = gson.toJson(data);
			URI url = new URI(urlString);
		    HttpPost request = new HttpPost(url);
		    StringEntity params =new StringEntity(json);
		    String encoding = Base64.getEncoder().encodeToString(("FSA.Pilot:abc@123").getBytes());
		    request.addHeader("Authorization", "Basic " + encoding);
		    request.addHeader("content-type", "application/json");
		    request.setEntity(params);
		    HttpResponse responseBody = httpClient.execute(request);
		    JSONObject response=new JSONObject(responseBody);
		    System.out.println(response.toString());
		    

		}catch (Exception ex) {

		    //handle exception here
		

		} 
	}
}
