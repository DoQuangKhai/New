package com.vsii.tsc.model;

public class GiaoDich {

	private String nguoiDatLenh;
	private String soHieuLenh;
	private String ngayGD;
	private String loaiLenh;
	private String quy;
	private String soCCQ;
	private String tongTien;
	private String trangThai;
	private String thaoTac;
	
	public String getNguoiDatLenh() {
		return nguoiDatLenh;
	}

	public void setNguoiDatLenh(String nguoiDatLenh) {
		this.nguoiDatLenh = nguoiDatLenh;
	}

	public String getSoHieuLenh() {
		return soHieuLenh;
	}

	public void setSoHieuLenh(String soHieuLenh) {
		this.soHieuLenh = soHieuLenh;
	}

	public String getNgayGD() {
		return ngayGD;
	}

	public void setNgayGD(String ngayGD) {
		this.ngayGD = ngayGD;
	}

	public String getLoaiLenh() {
		return loaiLenh;
	}

	public void setLoaiLenh(String loaiLenh) {
		this.loaiLenh = loaiLenh;
	}

	public String getQuy() {
		return quy;
	}

	public void setQuy(String quy) {
		this.quy = quy;
	}

	public String getSoCCQ() {
		return soCCQ;
	}

	public void setSoCCQ(String soCCQ) {
		this.soCCQ = soCCQ;
	}

	public String getTongTien() {
		return tongTien;
	}

	public void setTongTien(String tongTien) {
		this.tongTien = tongTien;
	}

	public String getTrangThai() {
		return trangThai;
	}

	public void setTrangThai(String trangThai) {
		this.trangThai = trangThai;
	}

	public String getThaoTac() {
		return thaoTac;
	}

	public void setThaoTac(String thaoTac) {
		this.thaoTac = thaoTac;
	}

	public void setThongTinGiaoDich(String nguoiDatLenh, String ngayGD, String loaiLenh, String quy, String tongTien){
		
	}
	
	public GiaoDich() {
		
	}

}
