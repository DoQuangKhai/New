package com.vsii.tsc.utility.net;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

public class JsonHelper {
	public void TS_126(List<String> items, String response) throws JSONException {
		final JSONObject obj = new JSONObject(response);
		final org.json.JSONArray data = obj.getJSONArray("Data");
		final int n = data.length();
		for (int i = 0; i < n; ++i) {
		  final JSONObject person = data.getJSONObject(i);
		  String fname = person.getString("FirstName");
		  String lname = person.getString("LastName");
		  String fullname = fname + "."+lname;
		  //System.out.println(fullname);
		  items.add(fullname);
		}
	}
	
	public void TS_131(List<String> items, String response){
		try {
			JSONObject obj = new JSONObject(response);
			final org.json.JSONArray data = obj.getJSONArray("Data");
			final int n = data.length();
			for (int i = 0; i < n; ++i) {
			  final JSONObject person = data.getJSONObject(i);
			  String fname = person.getString("FirstName");
			  String lname = person.getString("LastName");
			  String techid = person.getString("TechId");

			  String entity = fname + "."+ lname + "." + techid;
			  items.add(entity);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	
	
	public List<String> TH_17(List<String> items, String response){
		try {
			List<String> results = new ArrayList<String>();
			JSONObject obj = new JSONObject(response);
			final org.json.JSONArray data = obj.getJSONArray("Data");
			final int n = data.length();
			for (int i = 0; i < n; ++i) {
			  final JSONObject person = data.getJSONObject(i);
			  
			  if(person.getString("Primary") == "true"){
				  results.add(person.getString("TeamCode"));
			  }
			}
			return results;
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<String>();
		}		
	}
	public void TH_18(List<String> items, String response){
			try {
				JSONObject obj = new JSONObject(response);
				final org.json.JSONArray data = obj.getJSONArray("Data");
				final int n = data.length();
				for (int i = 0; i < n; ++i) {
				  final JSONObject person = data.getJSONObject(i);
				  String fname = person.getString("");
				  String lname = person.getString("LastName");
				  String techid = person.getString("TechId");

				  String entity = fname + "."+ lname + "." + techid;
				  items.add(entity);
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
	}
	
}
