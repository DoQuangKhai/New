package com.vsii.tsc.model;

public class TimeSheetHistory
{
    private String employeeName;
    private String screeningCode;
    private String totalHours;
    private String whoApproved;
    private String dateApproved;
    private String timeApproved;
    
    
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getScreeningCode() {
		return screeningCode;
	}
	public void setScreeningCode(String screeningCode) {
		this.screeningCode = screeningCode;
	}
	public String getTotalHours() {
		return totalHours;
	}
	public void setTotalHours(String totalHours) {
		this.totalHours = totalHours;
	}
	public String getWhoApproved() {
		return whoApproved;
	}
	public void setWhoApproved(String whoApproved) {
		this.whoApproved = whoApproved;
	}
	public String getDateApproved() {
		return dateApproved;
	}
	public void setDateApproved(String dateApproved) {
		this.dateApproved = dateApproved;
	}
	public String getTimeApproved() {
		return timeApproved;
	}
	public void setTimeApproved(String timeApproved) {
		this.timeApproved = timeApproved;
	}

}