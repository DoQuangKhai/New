package com.vsii.tsc.utility.sql;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.ibatis.common.jdbc.ScriptRunner;
import com.vsii.tsc.utility.action.CommonOperations;

public class DBConnection {
	static Properties p;
	public static Connection conn = null;

	// Use when querry return a result set
	public static ResultSet executeQuery(String sqlCommand) throws IOException {

		p = CommonOperations.readConfig();
		ResultSet rs = null;
		Statement stmt = null;

		// Driver of database
		String driver = getDataBaseDriver(p.getProperty("dbType"));

		// Perform connection
		try {
			// Loading the driver and creating its instance
			Class.forName(driver).newInstance();
			// Establishing the connection with the database

			conn = DriverManager.getConnection(getConnectionString(p.getProperty("dbType")));
			/*
			 * createStatement() method creates a Statement object for sending
			 * SQL to the database. It executes the SQL and returns the result
			 * it produces
			 */
			stmt = conn.createStatement();
			/*
			 * executeQuery() method executes the SQL statement which returns a
			 * single ResultSet type object.
			 */
			rs = stmt.executeQuery(sqlCommand);

		} catch (Exception e) {
			System.out.println("Couldn't connect to DB");
			System.out.print(e);

		}
		
		return rs;
		
	}

	// Use when querry does not return any Result set
	public static void executeUpdate(String sqlCommand) throws IOException {

		p = CommonOperations.readConfig();
		Statement stmt = null;

		// Driver of database
		String driver = getDataBaseDriver(p.getProperty("dbType"));

		// Perform connection
		try {
			// Loading the driver and creating its instance
			Class.forName(driver).newInstance();
			// Establishing the connection with the database

			conn = DriverManager.getConnection(getConnectionString(p.getProperty("dbType")));
			/*
			 * createStatement() method creates a Statement object for sending
			 * SQL to the database. It executes the SQL and returns the result
			 * it produces
			 */
			stmt = conn.createStatement();
			/*
			 * executeQuery() method executes the SQL statement which returns a
			 * single ResultSet type object.
			 */
			stmt.executeUpdate(sqlCommand);
			conn.close();

		} catch (Exception e) {
			System.out.println("Couldn't connect to DB");
			System.out.print(e);

		}

	}

	// Get database driver
	public static String getDataBaseDriver(String dbType) {
		String dbDriver = null;
		switch (dbType) {
		case "SQL":
			dbDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			break;
		case "MySQL":
			dbDriver = "com.mysql.jdbc.Driver";
			break;
		case "Oracle":
			dbDriver = "oracle.jdbc.driver.OracleDriver";
			break;
		default:
			break;
		}
		return dbDriver;
	}

	// Get connection string
	public static String getConnectionString(String dbType) throws IOException {
	    p = CommonOperations.readConfig();
		String connection = null;
		
		switch (dbType) {

		case "SQL":
			connection = "jdbc:sqlserver://" + p.getProperty("dbAddress") + ";databaseName=" + p.getProperty("dbName")
					+ ";user=" + p.getProperty("dbUser") + ";password=" + p.getProperty("dbPwd");
			break;
		case "MySQL":
			connection = "jdbc:mysql://" + p.getProperty("dbAddress") + "/" + p.getProperty("dbName") + "?" + "user="
					+ p.getProperty("dbUser") + "&password=" + p.getProperty("dbPwd");
			break;
		case "Oracle":
			connection = "jdbc:oracle:thin:" + p.getProperty("dbUser") + "/" + p.getProperty("dbPwd") + "@"
					+ p.getProperty("dbAddress") + ":" + p.getProperty("dbName");
			break;
		default:
			break;
		}

		return connection;
	}
	
	/**
     * 
     * <p>
     * Use this function to querry other db that not configure in properties file
     * </p>
     *
     * @since March 21 2017
     *
     */
	public static String getConnectionString(String dbType, String dbAddress, String dbName, String dbUser, String dbPwd) throws IOException {
        p = CommonOperations.readConfig();
        String connection = null;
        
        switch (dbType) {

        case "SQL":
            connection = "jdbc:sqlserver://" + dbAddress + ";databaseName=" + dbName
                    + ";user=" + dbUser + ";password=" + dbPwd;
            break;
        case "MySQL":
            connection = "jdbc:mysql://" + dbAddress + "/" + dbName + "?" + "user="
                    + dbUser + "&password=" + dbPwd;
            break;
        case "Oracle":
            connection = "jdbc:oracle:thin:" + dbUser + "/" + dbPwd + "@"
                    + dbAddress + ":" + dbName;
            break;
        default:
            break;
        }

        return connection;
    }

	public static boolean revertDB(String sqlCommand) throws IOException {

		p = CommonOperations.readConfig();
		Statement stmt = null;
		// String sqlCommand;

		// Defining the SQL URL
		String dbAddress = p.getProperty("dbAddress");
		String dbName = p.getProperty("dbName");
		String user = p.getProperty("dbUser");
		String pwd = p.getProperty("dbPwd");

		// Define sql command
		// sqlCommand = p.getProperty(sqlCommandName);

		// Driver of SQLServer
		String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String connection = "jdbc:sqlserver://" + dbAddress + ";databaseName=" + dbName + ";user=" + user + ";password="
				+ pwd;
		// Perform connection
		try {
			// Loading the driver and creating its instance
			Class.forName(driver).newInstance();
			// Establishing the connection with the database

			conn = DriverManager.getConnection(connection);
			/*
			 * createStatement() method creates a Statement object for sending
			 * SQL to the database. It executes the SQL and returns the result
			 * it produces
			 */
			stmt = conn.createStatement();
			/*
			 * executeQuery() method executes the SQL statement which returns a
			 * single ResultSet type object.
			 */
			return stmt.execute(sqlCommand);
		} catch (Exception e) {
			System.out.println("Couldn't connect to DB");
			System.out.print(e);

		} finally {
			try {
				conn.close();
				System.out.println("Take snapshot sucessfully");
			} catch (SQLException e) {
				System.out.println("Couldn't close connection");
				System.out.print(e);
			}
		}
		return false;
	}
	
	/**
	 * <p>
	 * This method used for execute sql script from an external file.
	 * The script in external file should not be SELECT statements 
	 * </p>
	 *
	 * @since March 9 2017
	 * @param dbType type of database (SQL, MySQL...)
	 * @param scriptPath path to sql script file
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * @author thanhvc
	 */
	public static void executeScriptFile(String dbType, String scriptPath)
        throws ClassNotFoundException, SQLException, IOException
    {

        String aSQLScriptFilePath = scriptPath;

        // Create MySql Connection
        Class.forName(getDataBaseDriver(dbType));

        Connection con = DriverManager.getConnection(getConnectionString(dbType));
        try
        {
            // Initialize object for ScripRunner
            ScriptRunner sr = new ScriptRunner(con, false, false);

            // Give the input file to Reader
            Reader reader = new BufferedReader(new FileReader(aSQLScriptFilePath));

            // Exctute script
            sr.runScript(reader);

            reader.close();
            con.close();

        }
        catch (Exception e)
        {
            System.err.println("Failed to Execute" + aSQLScriptFilePath + " The error is " + e.getMessage());
        }
    }
	
	/**
	 * 
	 * <p>
	 * Use this function to querry other db that not configure in properties file
	 * </p>
	 *
	 * @since March 21 2017
	 *
	 */
	public static ResultSet executeQuery(String sqlCommand, String dbType, String dbAddress, String dbName, String dbUser, String dbPwd) throws IOException {

        p = CommonOperations.readConfig();
        ResultSet rs = null;
        Statement stmt = null;

        // Driver of database
        String driver = getDataBaseDriver(p.getProperty("dbType"));

        // Perform connection
        try {
            // Loading the driver and creating its instance
            Class.forName(driver).newInstance();
            // Establishing the connection with the database

            conn = DriverManager.getConnection(getConnectionString(dbType, dbAddress, dbName, dbUser, dbPwd));
            /*
             * createStatement() method creates a Statement object for sending
             * SQL to the database. It executes the SQL and returns the result
             * it produces
             */
            stmt = conn.createStatement();
            /*
             * executeQuery() method executes the SQL statement which returns a
             * single ResultSet type object.
             */
            rs = stmt.executeQuery(sqlCommand);

        } catch (Exception e) {
            System.out.println("Couldn't connect to DB");
            System.out.print(e);

        }
        
        return rs;

    }

}
