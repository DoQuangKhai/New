//package com.vsii.tsc.utility.io;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.net.HttpURLConnection;
//import java.net.MalformedURLException;
//import java.net.URL;
//
//import org.testng.TestListenerAdapter;
//
//public class RedmineIntergration extends TestListenerAdapter {
//	String failedTest;
//
//	//This method used for log bug into redmine
//	public void postIssues(String redmineUrl, String redmineCredenfial, String redmineProjectId, String subject,
//			String description) {
//		try {
//
//			//Declare redmine API url
//			URL url = new URL(redmineUrl+"/issues.xml");
//			
//			//Declare basic authentication, format is username:password
//			String userPassword = redmineCredenfial;
//			@SuppressWarnings("restriction")
//			//Encode authentication
//			String encoding = new sun.misc.BASE64Encoder().encode(userPassword.getBytes());
//
//			//open connection to redmine API
//			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//			conn.setRequestProperty("Authorization", "Basic " + encoding);
//			conn.setDoOutput(true);
//			conn.setRequestMethod("POST");
//			conn.setRequestProperty("Content-Type", "application/xml");
//
//			//Define body text to send post request to redmine API
//			String input = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> " + "<issue> " + "<project_id>"
//					+ redmineProjectId + "</project_id> " + "<tracker_id>1</tracker_id> " + "<status_id>1</status_id> "
//					+ "<priority_id>2</priority_id> " + "<assigned_to_id>1</assigned_to_id> " + "<subject>" + subject
//					+ "</subject> " + "<description>" + description + "</description> "
//					+ "<is_private>false</is_private> " + "<estimated_hours/> " + "</issue>";
//
//			OutputStream os = conn.getOutputStream();
//			os.write(input.getBytes());
//			os.flush();
//
//			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
//				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
//			}
//
//			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
//
//			String output;
//			//Write output from server to console
//			System.out.println("Output from Server .... \n");
//			while ((output = br.readLine()) != null) {
//				System.out.println(output);
//			}
//
//			//Disconnect URL to release memory
//			conn.disconnect();
//
//		} catch (MalformedURLException e) {
//
//			e.printStackTrace();
//
//		} catch (IOException e) {
//
//			e.printStackTrace();
//
//		}
//	}
//
//}
