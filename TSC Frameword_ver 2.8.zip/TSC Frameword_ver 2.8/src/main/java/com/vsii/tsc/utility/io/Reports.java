package com.vsii.tsc.utility.io;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.testng.xml.XmlSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.vsii.tcbs.testcase.TestBase;

public class Reports extends TestListenerAdapter implements IReporter {
	public static ExtentReports extent;
	public ITestResult result;
	public String categoryName;
	public String htmlReportName;
	ITestContext context;
//	public RedmineIntergration redmine = new RedmineIntergration();

	public ReportHandle reportHandle;

	@Override
	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
		/*
		 * Due to issue Listener method is called multiple
		 * times(https://github.com/cbeust/testng/issues/171) if we have
		 * multiple test elements in testng.xml file, we need to create the
		 * variable "isGeneratedReport" to prevent generateReport is called
		 * multiple times
		 */
		if (TestBase.isGeneratedReport == false) {
			// Create new excel report & html report if report is not create yet
			if (reportHandle == null)
				reportHandle = new ReportHandle();
			// for each <suite>
			for (ISuite suite : suites) {
				Map<String, ISuiteResult> result = suite.getResults();
				SimpleDateFormat sdfDate = new SimpleDateFormat("yyMMddHHmm");// dd/MM/yyyy
				Date now = new Date();
				TestBase.timeReport = sdfDate.format(now);
				System.out.println(TestBase.timeReport);
				// for each <test>
				for (ISuiteResult r : result.values()) {
					context = r.getTestContext();
//					categoryName = context.getName();
//					/* Excel Report */
//					reportHandle.exportExcelReport(categoryName);
					/* HTML Report */
					if (extent == null) {
						htmlReportName = TestBase.p.getProperty("reportPath") + TestBase.p.getProperty("reportFile")
								+ TestBase.timeReport + ".html";
						extent = new ExtentReports(htmlReportName, true);
					}
//					try {
//						reportHandle.buildTestNodes(extent, context.getPassedTests(), LogStatus.PASS, categoryName);
//						reportHandle.buildTestNodes(extent, context.getFailedTests(), LogStatus.FAIL, categoryName);
//						reportHandle.buildTestNodes(extent, context.getSkippedTests(), LogStatus.SKIP, categoryName);
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
				}
			}
			TestBase.isGeneratedReport = true;
			extent.flush();
			extent.close();

		}

	}

	/**
	 * @author thanhvc
	 * @return List of bugs for all failed testscript and log them to Redmine
	 */
//	@Override
//	public void onTestFailure(ITestResult tr) {
//		// Store failed test id and description of bug
//		String failedTestName = tr.getName();
//		String failedTestDes = tr.getThrowable().getMessage();
//
//		// If parameter redmineAPIUrl is define, then log bug to redmine for all
//		// failed tests
//		if (!TestBase.redmineUrl.isEmpty()) {
//			// log bug into redmine base on testname failed
//			redmine.postIssues(TestBase.redmineUrl, TestBase.redmineCredenfial, TestBase.redmineProjectId,
//					"Testcase " + failedTestName + " failed", failedTestDes);
//		}
//	}
}
