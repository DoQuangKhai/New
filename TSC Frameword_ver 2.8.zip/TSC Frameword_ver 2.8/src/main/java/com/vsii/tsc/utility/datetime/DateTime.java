package com.vsii.tsc.utility.datetime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTime {
	public static String createDateText(String format){
		Date date = new Date() ;
		SimpleDateFormat dateFormat = new SimpleDateFormat(format) ;
		String dateText = dateFormat.format(date);
		return dateText;
		
	}
	
	//Convert string to date time
	public static Date stringToDate(String format, String dateInString) throws ParseException{
	    SimpleDateFormat dateFormat = new SimpleDateFormat(format);
	    Date date = dateFormat.parse(dateInString);
	    return date;
	}

}
