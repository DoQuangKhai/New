package com.vsii.tsc.utility.action;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;

import com.vsii.tcbs.testcase.TestBase;
import com.vsii.tsc.utility.datetime.DateTime;

public class CommonOperations
{

    List<String> list = null;

    /*
     * Read from configuration file
     */
    public static Properties readConfig() throws IOException
    {
        // Create new properties variable
        Properties p = new Properties();
        // Read object properties file
        InputStream stream = new FileInputStream("./properties/config.properties");
        // Load input stream file
        p.load(stream);

        //Close input stream
        stream.close();
        return p;
    }

    //---------------------------------------------------------------------------
    /*
     * Accept Alert
     */

    public static void closePopup()
    {
        Alert alert = TestBase.driver.switchTo().alert();
        alert.accept();
    }

    //---------------------------------------------------------------------------
    /*
     * Get Alert
     */
    public static boolean isAlertPresent(WebDriver driver)
    {
        boolean foundAlert = false;
        WebDriverWait wait = new WebDriverWait(driver, 0 /* timeout in seconds */);
        try
        {
            wait.until(ExpectedConditions.alertIsPresent());
            foundAlert = true;
        }
        catch (TimeoutException eTO)
        {
            foundAlert = false;
        }
        return foundAlert;
    }

    //---------------------------------------------------------------------------
    /*
     * Take picture after test
     */
    public synchronized static void takePicture(String browser, String methodName, String result) throws Exception
    {
        TestBase.imageName = "[" + browser.toUpperCase() + "]_" + methodName + "_"
            + DateTime.createDateText("yyyyMMddHHmmss") + "-" + result;
        // Capture popup
        if (CommonOperations.isAlertPresent(TestBase.driver))
        {
            String dir = TestBase.p.getProperty("imagePath");
            createDir(dir);
            captureScreenShotPopUp(dir + TestBase.imageName);
            closePopup();
        }
        // Capture screen
        else
        {
            CaptureScreen(TestBase.driver, TestBase.imageName);
        }
        //System.out.println("Image List Size" + TestBase.imageList.size());

    }

    /*
     * Capture screen
     */
    public static String CaptureScreen(WebDriver driver, String captureName) throws IOException
    {
        Properties p = readConfig();
        String imagePath;
        String imageName;
        imagePath = p.getProperty("imagePath") + captureName;
        TakesScreenshot oScn = (TakesScreenshot) driver;
        File oScnShot = oScn.getScreenshotAs(OutputType.FILE);
        File oDest = new File(imagePath + ".jpg");
        try
        {
            FileUtils.copyFile(oScnShot, oDest);
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
        }
        imageName = imagePath + ".jpg";
        return imageName;
    }

    /*
     * Capture screenshot
     */
    public static String captureScreenShotPopUp(String img) throws Exception
    {
        BufferedImage bfImage =
            new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        ImageIO.write(bfImage, "png", new File(img + ".jpg"));
        String imageName = img + ".jpg";
        return imageName;

    }

    //-------------------------------------------------------------------------------
    /*
     * Verify Element Present
     */
    public static boolean verifyElementPresent(WebElement element)
    {

        if (element.isDisplayed())
        {
        	System.out.println(element.toString()+ " is displayed");
            return true;
        }
        else
        	System.out.println(element.toString()+ " is NOT displayed");
            return false;

    }

    //-------------------------------------------------------------------------------
    /*
     * Create Directory
     */
    public static void createDir(String dir)
    {
        String directoryName = dir;
        File theDir = new File(directoryName);
        if (!theDir.exists())
        {
            theDir.mkdir();
        }
    }

    /*
     * Check a file exist or not
     */
    public static boolean isFileExist(File fileName)
    {
        if (fileName.exists())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /*
     * get test result of each test method
     */
    public static String getMethodTestResult(ITestResult testResult)
    {
        int resultCode = testResult.getStatus();
        if (resultCode == 1)
        {
            TestBase.testStatus = "Passed";
        }
        else if (resultCode == 2)
        {
            TestBase.testStatus = "Failed";
        }
        else if (resultCode == 3)
        {
            TestBase.testStatus = "Skipped";
        }
        return TestBase.testStatus;
    }

    /**
     * 
     * <p>
     * This method used for wait FSAG only, wait for loading incon is loaded completely
     * </p>
     * 
     * @author thanhvc
     * @since 03/21/2017
     */
    public static void waitForFSAGToLoad(WebDriver driver, int timeInSecond)
    {
        WebDriverWait wait = new WebDriverWait(driver, timeInSecond);
        //Wait for loading img displayed
        wait.until(new ExpectedCondition<Boolean>()
        {
            public Boolean apply(WebDriver d)
            {
                return d.findElement(By.tagName("body")).getAttribute("aria-busy").equals("true");
            }
        });

        //Then wait for it disappreared
        wait.until(new ExpectedCondition<Boolean>()
        {
            public Boolean apply(WebDriver d)
            {
                return d.findElement(By.tagName("body")).getAttribute("aria-busy").equals("false");
            }
        });
    }

    /**
     * <p>
     * Ensure element to be clickable if it visibled on page but sometime in loading time, it had overflowed by other
     * element (like div element)
     * </p>
     *
     * @since Jul 11, 2017
     * @param element
     *            element want to click on
     * @param tryTime
     *            try time in second to click to element
     */
    public static void performClick(WebElement element, int tryTime)
    {
        for (int i = 0; i < tryTime; i++)
        {
            try
            {
                element.click();
                break;
            }
            catch (Exception e)
            {
                try
                {
                    Thread.sleep(1000);
                }
                catch (Exception e2)
                {
                    e2.printStackTrace();
                }
            }
        }
    }
    
    /**
     * <p>
     * When an element is visible, this function will wait until this element is invisible during waitTime
     *</p>
     * @since Aug 31, 2017
     * @param element
     * 				element expect to invisible
     * @param waitTime
     * 				max wait time
     * 
     * @author khaidq
     */
    public static void waitForElementInvisible(WebElement element, int waitTime){
    	Long startTime = System.currentTimeMillis();
        try {
            while (System.currentTimeMillis() - startTime < waitTime * 500 && element.isDisplayed()) {}
        } catch (StaleElementReferenceException e) {
            return;
        }
    }
    
    /**
     * <p>
     * When an element is invisible, this function will wait until this element is Visible during waitTime
     *</p>
     * @since Aug 31, 2017
     * @param element
     * 				element expect to visible
     * @param waitTime
     * 				max wait time
     * 
     * @author khaidq
     */
    public static void waitForElementVisible(WebElement element, int waitTime){
    	Long startTime = System.currentTimeMillis();
        try {
            while (System.currentTimeMillis() - startTime < waitTime * 500 && !element.isDisplayed()) {}
        } catch (StaleElementReferenceException e) {
            return;
        }
    }
    
    /**
     * <p>
     * This function perform click an element by using javascript
     * </p>
     * @param element
     * 				element that want to click
     * @param driver
     * 				
     */
    public static void clickUsingJS(WebElement element, WebDriver driver){
    	JavascriptExecutor executor = (JavascriptExecutor)driver;
    	executor.executeScript("arguments[0].click();", element);
    }
}
