package com.vsii.tsc.utility.common;

public class Constant {
	 public static class Message{
		 public static String REQUIRE_SELECT_APPROVER = "Please select 1 approver.";	
		 public static String REQUIRE_MARK_WORKINGTODAY_FOR_APPROVER= "Approver must be added into this ScreeningCode";
		 public static String REQUIRE_SELECT_POSITION = "You have not selected a work position for one or more employees � please close this error message and select a work position for them, add employee signature, and save. Thank you.";
		 public static String REQUIRE_MARK_WORKINGTODAY_FOR_EMPLOYEE = "You have not marked as \"working today\" for one or more employees - please close this error message and select \"working today\" check box as selected for them. Thank you.";
		 public static String INFORM_NO_SCREENING = "There's no screening scheduled for ${teamCode} team on ${screeningDate}";
		 public static String REQUIRE_SCREENINGCODE ="Screening Code is required!";
		 public static String NO_DATA_ON_GRID_ADD_EMPLOYEE ="No data available in table";
		 public static String REQUIRE_SELECT_EMPLOYEE_TO_ADD= "Please select employee to add.";
		 public static String INFORM_EMPLOYEES_ARE_ADDED = "The selected employees are added to employees list.";
		 public static String DRIVE_TIME_TO_SITE_INVALID = "Drive Time To Site - Invalid, Please enter Start time and End time.";
		 public static String SAVED = "Saved";
		 public static String SETUP_INVALID =  "Setup - Invalid, Please enter Start time and End time.";
	 }
}
