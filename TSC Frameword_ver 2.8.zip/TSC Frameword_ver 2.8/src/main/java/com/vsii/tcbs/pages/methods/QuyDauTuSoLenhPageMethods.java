package com.vsii.tcbs.pages.methods;

import org.openqa.selenium.WebDriver;
import com.vsii.tcbs.pages.QuyDauTuSoLenhPage;
import com.vsii.tsc.utility.action.CommonOperations;
import com.vsii.tsc.utility.common.TableHandle;

import org.openqa.selenium.support.PageFactory;

public class QuyDauTuSoLenhPageMethods {
	WebDriver driver;
	QuyDauTuSoLenhPage objQuyDauTuSoLenhPage = new QuyDauTuSoLenhPage();
	
	/*
	 * Intitiazation function of QuyDauTuSoLenhPageMethods
	 */
	public QuyDauTuSoLenhPageMethods(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, objQuyDauTuSoLenhPage);
	}
	
	/*
	 * Action Wait for Loading image is disappeared
	 */
	public QuyDauTuSoLenhPageMethods waitForLoadingCompleted(){
		CommonOperations.waitForElementVisible(objQuyDauTuSoLenhPage.getImgLoading(), 20000);
		CommonOperations.waitForElementInvisible(objQuyDauTuSoLenhPage.getImgLoading(), 20000);
		return this;
	}
	
	/*
	 * Action Get info of Transaction
	 */
	public QuyDauTuSoLenhPageMethods getInfoTransaction(String textToCompare, int position){
		System.out.println(TableHandle.getAllColumnValuesInCurrentPage(driver, 1, 1));
		return this;
	}
}
