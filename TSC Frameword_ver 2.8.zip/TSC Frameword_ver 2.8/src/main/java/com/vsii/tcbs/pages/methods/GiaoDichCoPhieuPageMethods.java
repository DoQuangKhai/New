package com.vsii.tcbs.pages.methods;

import com.vsii.tcbs.pages.GiaoDichCoPhieuPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.vsii.tsc.utility.action.CommonOperations;

public class GiaoDichCoPhieuPageMethods {
	WebDriver driver;
	GiaoDichCoPhieuPage objGiaoDichCoPhieuPage = new GiaoDichCoPhieuPage();
	
	/*
	 * Initialization function of GiaoDichCoPhieuPageMethods class 
	 */
	public GiaoDichCoPhieuPageMethods(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, objGiaoDichCoPhieuPage);
	}
	
	/*
	 * Action click on Quy dau tu navigation
	 */
	public GiaoDichCoPhieuPageMethods clickQuyDauTuTab(){
		CommonOperations.performClick(objGiaoDichCoPhieuPage.getTabQuyDauTu(), 5);
		return this;
	}
}
