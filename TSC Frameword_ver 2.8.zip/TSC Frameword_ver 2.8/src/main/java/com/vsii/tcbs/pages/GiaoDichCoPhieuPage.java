package com.vsii.tcbs.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GiaoDichCoPhieuPage {
	//Quy Dau tu tab
	@FindBy(xpath= "/html/body/div[2]/div/div/div/div[1]/div/div/ul/li[3]")
	private WebElement tabQuyDauTu;
	public WebElement getTabQuyDauTu(){
		return tabQuyDauTu;
	}
}
