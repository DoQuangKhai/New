package com.vsii.tcbs.pages.methods;

import org.openqa.selenium.WebDriver;
import com.vsii.tcbs.pages.GiaoDichQuyDauTuPage;
import org.openqa.selenium.support.PageFactory;
import com.vsii.tsc.utility.action.CommonOperations;

public class GiaoDichQuyDauTuPageMethods {
	WebDriver driver;
	GiaoDichQuyDauTuPage objGiaoDichQuyDauTuPage = new GiaoDichQuyDauTuPage();
	
	
	/*
	 * Intitiazation function of GiaoDichQuyDauTuPageMethods 
	 */
	public GiaoDichQuyDauTuPageMethods(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, objGiaoDichQuyDauTuPage);
	}
	
	/*
	 * Action click on Mua TCBF button
	 */
	public GiaoDichQuyDauTuPageMethods clickMuaTCBFBtn(){
		CommonOperations.waitForElementVisible(objGiaoDichQuyDauTuPage.getBtnMuaTCBF(), 10000);
		CommonOperations.performClick(objGiaoDichQuyDauTuPage.getBtnMuaTCBF(), 5);
		return this;
	}
}
