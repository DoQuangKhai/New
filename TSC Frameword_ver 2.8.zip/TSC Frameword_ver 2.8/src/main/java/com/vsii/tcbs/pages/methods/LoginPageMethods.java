package com.vsii.tcbs.pages.methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.vsii.tcbs.pages.LoginPage;

public class LoginPageMethods {
	WebDriver driver;
    LoginPage objLoginPage = new LoginPage();

    /*
     * Initialization function of LoginPageMethods class
     */
	public LoginPageMethods(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, objLoginPage);
    }
	
	/*
	 * Action Login to TCBS
	 */
	public LoginPageMethods login(String username, String password){
		objLoginPage.getTxtUsername().sendKeys(username);
		objLoginPage.getTxtPassword().sendKeys(password);
		objLoginPage.getBtnLogin().click();
		return this;
	}
}
