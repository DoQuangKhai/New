package com.vsii.tcbs.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class QuyDauTuSoLenhPage {
	//Loading image
	@FindBy(xpath = "//div[@class='loading-overlay']/img[@src='assets/images/spin.svg']")
	private WebElement imgLoading;
	public WebElement getImgLoading(){
		return imgLoading;
	}
}
