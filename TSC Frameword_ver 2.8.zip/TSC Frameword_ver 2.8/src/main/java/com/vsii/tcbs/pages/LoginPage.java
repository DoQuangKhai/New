package com.vsii.tcbs.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
    //Username textbox 
    @FindBy(xpath = "//*[@id='username UID']")
    private WebElement txtUsername;
    public WebElement getTxtUsername(){
        return txtUsername;
    }
    
    //Password textbox 
    @FindBy(xpath = "//*[@id='password']")
    private WebElement txtPassword;
    public WebElement getTxtPassword(){
        return txtPassword;
    }

    //Login button
    @FindBy(xpath = "//*[@id='custom-login']/div[3]/input[4]")
    private WebElement btnLogin;
    public WebElement getBtnLogin(){
    	return btnLogin;
    }
}
