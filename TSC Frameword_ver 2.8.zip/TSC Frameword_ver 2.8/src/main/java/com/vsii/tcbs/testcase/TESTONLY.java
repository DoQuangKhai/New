/*
 * FILENAME
 *     TESTONLY.java
 *
 * FILE LOCATION
 *     $Source$
 *
 * VERSION
 *     $Id$
 *         @version       $Revision$
 *         Check-Out Tag: $Name$
 *         Locked By:     $Lockers$
 *
 * FORMATTING NOTES
 *     * Lines should be limited to 78 characters.
 *     * Files should contain no tabs.
 *     * Indent code using four-character increments.
 *
 * COPYRIGHT
 *     Copyright (C) 2007 Genix Ventures Pty. Ltd. All rights reserved.
 *     This software is the confidential and proprietary information of
 *     Genix Ventures ("Confidential Information"). You shall not
 *     disclose such Confidential Information and shall use it only in
 *     accordance with the terms of the license agreement you entered into
 *     with Genix Ventures.
 */

package com.vsii.tcbs.testcase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//
// IMPORTS
// NOTE: Import specific classes without using wildcards.
//

public class TESTONLY
{
    public static void main(String[] args)
    {
        HashMap<String, List<String>> hm = new HashMap<>();

        List<String> names = new ArrayList<>();
        names.add("ThaoNP");
        names.add("QuyenTX");
        names.add("ChienPT");

        List<String> jobs = new ArrayList<>();
        jobs.add("Tech");
        jobs.add("Boss");
        jobs.add("Staff");

        hm.put("Name", names);
        hm.put("Job", jobs);

        int noOfRow = hm.get("Job").size();
        int noOfKey = hm.keySet().size();

        //        System.out.print(hm.keySet().toArray()[0]);
        //        System.out.print("\t" + hm.keySet().toArray()[1]);
        for (int t = 0; t < noOfKey; t++)
        {
            System.out.print(hm.keySet().toArray()[t]);
            System.out.print("\t");

        }
        System.out.println();
        int t = 0;
        for (int i = 0; i < noOfRow; i++)
        {
            System.out.print(hm.get(hm.keySet().toArray()[t]).get(i));
            t++;
            while (t < noOfKey)
            {
                System.out.print("\t" + hm.get(hm.keySet().toArray()[t]).get(i));
                t++;
            }
            System.out.println();
            if (t == noOfKey)
            {
                t = 0;
            }
        }

    }
}
