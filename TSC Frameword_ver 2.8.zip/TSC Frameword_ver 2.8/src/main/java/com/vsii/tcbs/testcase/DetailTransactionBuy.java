package com.vsii.tcbs.testcase;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.vsii.tcbs.pages.methods.LoginPageMethods;
import com.vsii.tcbs.pages.methods.QuyDauTuSoLenhPageMethods;
import com.vsii.tcbs.pages.methods.TongQuanPageMethods;
import com.vsii.tcbs.pages.methods.GiaoDichCoPhieuPageMethods;
import com.vsii.tcbs.pages.methods.GiaoDichQuyDauTuPageMethods;
import com.vsii.tcbs.pages.methods.MuaQuyDauTuPageMethods;
import com.vsii.tsc.model.GiaoDich;

public class DetailTransactionBuy extends TestBase {
	LoginPageMethods loginPage;
	TongQuanPageMethods tongQuanPage;
	GiaoDichCoPhieuPageMethods giaoDichCoPhieuPage;
	GiaoDichQuyDauTuPageMethods giaoDichQuyDauTuPage;
	MuaQuyDauTuPageMethods muaQuyDauTuPage;
	QuyDauTuSoLenhPageMethods quyDauTuSoLenhPage;
	
	@BeforeMethod
    public void setup(){
        loginPage = new LoginPageMethods(driver);
        tongQuanPage = new TongQuanPageMethods(driver);
        giaoDichCoPhieuPage = new GiaoDichCoPhieuPageMethods(driver);
        giaoDichQuyDauTuPage = new GiaoDichQuyDauTuPageMethods(driver);
        muaQuyDauTuPage = new MuaQuyDauTuPageMethods(driver);
        quyDauTuSoLenhPage = new QuyDauTuSoLenhPageMethods(driver);
    }
	
//	@Test
//    public void TC001(){
//        loginPage.login("105C983857", "abc123");
//        tongQuanPage.clickGiaoDichNav();
//        giaoDichCoPhieuPage.clickQuyDauTuTab();
//        giaoDichQuyDauTuPage.clickMuaTCBFBtn();
//        muaQuyDauTuPage.enterSoTienTxt("999999");
//        muaQuyDauTuPage.clickTiepTucBtn();
//        Assert.assertTrue(muaQuyDauTuPage.verifyCanhBao1Msg("Số tiền đầu tư tối thiểu 1,000,000 VNĐ!"));
//	}
//	
//	@Test
//    public void TC002(){
//        loginPage.login("105C983857", "abc123");
//        tongQuanPage.clickGiaoDichNav();
//        giaoDichCoPhieuPage.clickQuyDauTuTab();
//        giaoDichQuyDauTuPage.clickMuaTCBFBtn();
//        muaQuyDauTuPage.enterSoTienTxt("10000002");
//        muaQuyDauTuPage.clickTiepTucBtn();
//        muaQuyDauTuPage.clickDatLenhBtn();
//        Assert.assertTrue(muaQuyDauTuPage.verifyCanhBao2Msg("Điều khoản chưa được xác nhận"));
//	}

	GiaoDich giaoDichSoLenh003;
	GiaoDich giaoDichDatLenh003;
	@Test
    public void TC003(){
        loginPage.login("105C983857", "abc123");
        tongQuanPage.clickGiaoDichNav();
        giaoDichDatLenh003.setNguoiDatLenh(tongQuanPage.name);
        giaoDichCoPhieuPage.clickQuyDauTuTab();
        giaoDichQuyDauTuPage.clickMuaTCBFBtn();
        muaQuyDauTuPage.selectLoaiQuyDauTu("TCBF");
        giaoDichDatLenh003.setQuy("TCBF");;
        muaQuyDauTuPage.selectNgayGiaoDich("07/09/2017");
        giaoDichDatLenh003.setNgayGD("07/09/2017");
        muaQuyDauTuPage.enterSoTienTxt("10,000,003");
        giaoDichDatLenh003.setTongTien("10,000,003");
        muaQuyDauTuPage.clickTiepTucBtn();
        muaQuyDauTuPage.tickXacNhanDieuKienCbx();
        muaQuyDauTuPage.clickDatLenhBtn();
        Assert.assertTrue(muaQuyDauTuPage.verifyCanhBao2Msg("Đặt lệnh thành công!"));
        Assert.assertTrue(muaQuyDauTuPage.verifyXacNhanThanhCongP1Msg("Quý khách đã đặt lệnh mua thành công. Xin cảm ơn."));
        Assert.assertTrue(muaQuyDauTuPage.verifyXacNhanThanhCongP2Msg("1. Chúng tôi đã gửi xác nhận kèm thông tin chuyển tiền đến email của Quý khách."));
        Assert.assertTrue(muaQuyDauTuPage.verifyXacNhanThanhCongP3Msg("2. Vui lòng chuyển tiền sớm từ Techcombank hoặc từ ngân hàng khác để tiền có thể đến ngân hàng giám sát của Quỹ trước 14h ngày 06/09/2017."));
        Assert.assertTrue(muaQuyDauTuPage.verifyXacNhanThanhCongP4Msg("3. Mọi thắc mắc vui lòng email TCFund_support@techcombank.com.vn hoặc gọi 1800 588 826."));
        muaQuyDauTuPage.clickBlankArea();
        quyDauTuSoLenhPage.waitForLoadingCompleted();
        quyDauTuSoLenhPage.getInfoTransaction("Số hiệu lệnh", 2);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
