package com.vsii.tcbs.pages.methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.vsii.tcbs.pages.MuaQuyDauTuPage;
import com.vsii.tsc.utility.action.CommonOperations;

import org.openqa.selenium.support.PageFactory;

public class MuaQuyDauTuPageMethods {
	WebDriver driver;
	MuaQuyDauTuPage objMuaQuyDauTuPage = new MuaQuyDauTuPage();
	public 	String[] thongTinGiaoDich = new String[3];

	
	
	/*
	 * Intitiazation function of MuaQuyDauTuPageMethods
	 */
	public MuaQuyDauTuPageMethods(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, objMuaQuyDauTuPage);
	}
	
	/*
	 * Action select Loai Quy dau tu
	 */
	public void selectLoaiQuyDauTu(String loaiQuyDauTu){
		thongTinGiaoDich[0] = loaiQuyDauTu;
		objMuaQuyDauTuPage.getSelLoaiQuyDauTu().click();
		objMuaQuyDauTuPage.getOtpLoaiQuyDauTu(loaiQuyDauTu, driver).click();
	}
	
	/*
	 * Action select Ngay giao dich
	 */
	public void selectNgayGiaoDich(String ngayGiaoDich){
		thongTinGiaoDich[1] = ngayGiaoDich;
		objMuaQuyDauTuPage.getSelNgayGiaoDich().click();
		objMuaQuyDauTuPage.getOtpNgayGiaoDich(ngayGiaoDich, driver).click();
	}
	
	/*
	 * Action enter to So tien textbox
	 */
	public MuaQuyDauTuPageMethods enterSoTienTxt(String soTien){
		thongTinGiaoDich[2] = soTien;
		objMuaQuyDauTuPage.getTxtSoTien().clear();
		objMuaQuyDauTuPage.getTxtSoTien().sendKeys(soTien);
		return this;
	}
	
	/*
	 * Action click on Tiep tuc button
	 */
	public MuaQuyDauTuPageMethods clickTiepTucBtn(){
		objMuaQuyDauTuPage.getBtnTiepTuc().click();
		return this;
	}
	
	/*
	 * Action tick on Xac nhan dieu kien checkbox
	 */
	public MuaQuyDauTuPageMethods tickXacNhanDieuKienCbx(){
		CommonOperations.performClick(objMuaQuyDauTuPage.getCbxXacNhanDieuKien(), 5);
		return this;
	}
	
	/*
	 * Action click on Dat Lenh button
	 */
	public MuaQuyDauTuPageMethods clickDatLenhBtn(){
		objMuaQuyDauTuPage.getBtnDatLenh().click();
		return this;
	}
	
	/*
	 * Action click on blank area
	 */
	public void clickBlankArea(){
		CommonOperations.performClick(driver.findElement(By.xpath("//html/body/div[1]")), 1);
	}
	
	/*
	 * Verify Canh bao 1 message
	 */
	public boolean verifyCanhBao1Msg(String message){
		return objMuaQuyDauTuPage.getMsgCanhBao1().getText().equalsIgnoreCase(message);
	}
	
	/*
	 * Verify Canh bao 2 message
	 */
	public boolean verifyCanhBao2Msg(String message){
		return objMuaQuyDauTuPage.getMsgCanhBao2().getText().equalsIgnoreCase(message);
	}
	
	/*
	 * Verify Xac nhan dat lenh thanh cong P1 message
	 */
	public boolean verifyXacNhanThanhCongP1Msg(String message){
		System.out.println();
		return objMuaQuyDauTuPage.getMsgXacNhanThanhCongP1().getText().equalsIgnoreCase(message);
	}

	/*
	 * Verify Xac nhan dat lenh thanh cong P2 message
	 */
	public boolean verifyXacNhanThanhCongP2Msg(String message){
		return objMuaQuyDauTuPage.getMsgXacNhanThanhCongP2().getText().equalsIgnoreCase(message);
	}

	/*
	 * Verify Xac nhan dat lenh thanh cong P3 message
	 */
	public boolean verifyXacNhanThanhCongP3Msg(String message){
		return objMuaQuyDauTuPage.getMsgXacNhanThanhCongP3().getText().equalsIgnoreCase(message);
	}

	/*
	 * Verify Xac nhan dat lenh thanh cong P4 message
	 */
	public boolean verifyXacNhanThanhCongP4Msg(String message){
		return objMuaQuyDauTuPage.getMsgXacNhanThanhCongP4().getText().equalsIgnoreCase(message);
	}
}
