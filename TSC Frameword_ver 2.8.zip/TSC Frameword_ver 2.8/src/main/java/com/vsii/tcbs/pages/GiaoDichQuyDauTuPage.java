package com.vsii.tcbs.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GiaoDichQuyDauTuPage {
	//Mua TCBF button
	@FindBy(xpath= "/html/body/div[2]/div/div/div/div[1]/div/div/div[1]/div/div[2]/div/div[2]/div[2]/div[1]/div/div[3]/div[1]/button")
	private WebElement btnMuaTCBF;
	public WebElement getBtnMuaTCBF(){
		return btnMuaTCBF;
	}
}
