package com.vsii.tcbs.main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class Main {

	public static Properties p;

	public static void main(String[] args) throws IOException {
		System.out.println("xxxx");
		XmlSuite suite;
		@SuppressWarnings("unused")
        XmlTest test, test2;
		List<XmlClass> classes;
		List<XmlSuite> suites;
		TestNG tng;

		suite = new XmlSuite();
		suite.setName("Suite");
		
		Map<String, String> paramSuite = new HashMap<String, String>();
		paramSuite.put("remoteUrl", "");
		paramSuite.put("redmineUrl", "");
		paramSuite.put("redmineCredenfial", "");
		paramSuite.put("redmineProjectId", "");
		suite.setParameters(paramSuite);
		
		// TestListenerAdapter tla = new TestListenerAdapter();
//		test = new XmlTest(suite);
//		test.setName("Login-chrome");
//		Map<String, String> params = new HashMap<String, String>();
//		params.put("broswer", "chrome");
//		params.put("sheetName", "Login");
//		test.setParameters(params);
//		classes = new ArrayList<XmlClass>();
//		classes.add(new XmlClass("com.vsii.fsag.testcase.Login"));
//		test.setXmlClasses(classes);
		
		
		test2 = new XmlTest(suite);
		test2.setName("Timesheet-chrome");
		Map<String, String> params2 = new HashMap<String, String>();
		params2.put("broswer", "chrome");
		params2.put("sheetName", "Timesheet");
		test2.setParameters(params2);
		classes = new ArrayList<XmlClass>();
		classes.add(new XmlClass("com.vsii.fsag.testcase.TESTONLY"));
		test2.setXmlClasses(classes);
		
		suites = new ArrayList<XmlSuite>();
		suites.add(suite);
		tng = new TestNG();
		tng.setXmlSuites(suites);
		tng.run();

	}
}
