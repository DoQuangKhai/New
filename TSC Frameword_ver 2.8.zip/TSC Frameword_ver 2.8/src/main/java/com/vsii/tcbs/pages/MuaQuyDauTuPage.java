package com.vsii.tcbs.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MuaQuyDauTuPage {
	
	//So Tien txt
	@FindBy(xpath = "/html/body/div[1]/div/div/div[3]/div[1]/div[4]/div[3]/table/tbody/tr/td[2]/input")
	private WebElement txtSoTien;
	public WebElement getTxtSoTien(){
		return txtSoTien;
	}
	
	//Tiep tuc button
	@FindBy(xpath = "/html/body/div[1]/div/div/div[3]/div[2]/div/div[2]/a")
	private WebElement btnTiepTuc;
	public WebElement getBtnTiepTuc(){
		return btnTiepTuc;
	}
	
	//Xac nhan dieu kien checkbox
	@FindBy(xpath = "/html/body/div[1]/div/div/div[3]/div[1]/div[5]/div/label/input")
	private WebElement cbxXacNhanDieuKien;
	public WebElement getCbxXacNhanDieuKien(){
		return cbxXacNhanDieuKien;
	}
	
	//Dat Lenh button
	@FindBy(xpath = "/html/body/div[1]/div/div/div[3]/div[2]/div/div[2]/a")
	private WebElement btnDatLenh;
	public WebElement getBtnDatLenh(){
		return btnDatLenh;
	}
	
	//Canh bao 1 message
	@FindBy(xpath = "//*[@id='fund-alert']")
	private WebElement msgCanhBao1;
	public WebElement getMsgCanhBao1(){
		return msgCanhBao1;
	}
	
	//Canh bao 2 message
	@FindBy(xpath = "//*[@id='toast-container']/div/div/div")
	private WebElement msgCanhBao2;
	public WebElement getMsgCanhBao2(){
		return msgCanhBao2;
	}
	
	//Thong tin xac nhan dat lenh thanh cong P1 message 
	@FindBy(xpath = "/html/body/div[1]/div/div/div/div[2]/div[2]/div/p[1]")
	private WebElement msgXacNhanThanhCongP1;
	public WebElement getMsgXacNhanThanhCongP1(){
		return msgXacNhanThanhCongP1;
	}
	
	//Thong tin xac nhan dat lenh thanh cong P2 message
	@FindBy(xpath = "html/body/div[1]/div/div/div/div[2]/div[2]/div/p[2]")
	private WebElement msgXacNhanThanhCongP2;
	public WebElement getMsgXacNhanThanhCongP2(){
		return msgXacNhanThanhCongP2;
	}
	
	//Thong tin xac nhan dat lenh thanh cong P3 message
	@FindBy(xpath = "/html/body/div[1]/div/div/div/div[2]/div[2]/div/p[3]")
	private WebElement msgXacNhanThanhCongP3;
	public WebElement getMsgXacNhanThanhCongP3(){
		return msgXacNhanThanhCongP3;
	}
	
	//Thong tin xac nhan dat lenh thanh cong P4 message
	@FindBy(xpath = "/html/body/div[1]/div/div/div/div[2]/div[2]/div/p[4]")
	private WebElement msgXacNhanThanhCongP4;
	public WebElement getMsgXacNhanThanhCongP4(){
		return msgXacNhanThanhCongP4;
	}
	
	//Ngay giao dich selectbox
	@FindBy(xpath = "html/body/div[1]/div/div/div[3]/div[1]/div[4]/div[1]/div[6]/div/select")
	private WebElement selNgayGiaoDich;
	public WebElement getSelNgayGiaoDich(){
		return selNgayGiaoDich;
	}
	
	//Ngay giao dich option
	public WebElement getOtpNgayGiaoDich(String ngayGiaoDich, WebDriver driver){
		return driver.findElement(By.xpath("html/body/div[1]/div/div/div[3]/div[1]/div[4]/div[1]/div[6]/div/select/option[text() = '"+ngayGiaoDich+"']"));
	}
	
	//Loai Quy dau tu selectbox
	@FindBy(xpath = "html/body/div[1]/div/div/div[3]/div[1]/div[2]/div[2]/select")
	private WebElement selLoaiQuyDauTu;
	public WebElement getSelLoaiQuyDauTu(){
		return selLoaiQuyDauTu;
	}
	
	//Loai Quy dau tu option
	public WebElement getOtpLoaiQuyDauTu(String loaiQuyDauTu, WebDriver driver){
		return driver.findElement(By.xpath("html/body/div[1]/div/div/div[3]/div[1]/div[2]/div[2]/select/option[contains(text(),'"+loaiQuyDauTu+"')]"));
	}
}
