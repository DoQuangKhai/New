package com.vsii.tcbs.pages.methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.vsii.tcbs.pages.TongQuanPage;
import com.vsii.tsc.utility.action.CommonOperations;


public class TongQuanPageMethods {
	WebDriver driver;
	TongQuanPage objTongQuanPage = new TongQuanPage();
	
	public String name = null;
	
	/*
     * Initialization function of TongQuanPageMethods class
     */
	public TongQuanPageMethods(WebDriver driver){
		this.driver = driver;
        PageFactory.initElements(driver, objTongQuanPage);
	}
	
	/*
	 * Action Click on Giao dich navigation
	 */
	public TongQuanPageMethods clickGiaoDichNav(){
		name = objTongQuanPage.getLblTenTaiKhoan().getText();
		CommonOperations.performClick(objTongQuanPage.getNavGiaoDich(), 5);
		return this;
	}
	
	/*
	 * Action Click on Giao Dich Quy Dau Tu button
	 */
	public TongQuanPageMethods clickGiaoDichQuyDauTuBtn(){
//		CommonOperations.waitForElementVisible(objTongQuanPage.getBtnGiaoDichQuyDauTu(), 20000);
		CommonOperations.clickUsingJS(objTongQuanPage.getBtnGiaoDichQuyDauTu(), driver);
//		CommonOperations.performClick(objTongQuanPage.getBtnGiaoDichQuyDauTu(), 5);
		return this;
	}
}
