package com.vsii.tcbs.testdata;

import org.testng.annotations.DataProvider;
import com.vsii.tsc.utility.io.ExcelHandle;;

public class TestData {
	@DataProvider(name = "LG_06")
	public static Object[][] checkUserIDBlank() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Login", "LG_06");
		return data;
	}

	@DataProvider(name = "LG_07")
	public static Object[][] checkPasswordBlank() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Login", "LG_07");
		return data;
	}

	@DataProvider(name = "LG_08")
	public static Object[][] incorrectCredentials() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Login", "LG_08");
		return data;
	}

	@DataProvider(name = "LG_09")
	public static Object[][] correctCredentialsAndTabs() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Login", "LG_09");
		return data;
	}
		
	@DataProvider(name = "LG_10")
	public static Object[][] loginSuccess() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Login", "LG_10");
		return data;
	}
	
	@DataProvider(name = "LG_11")
	public static Object[][] notAuthorized() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Login", "LG_11");
		return data;
	}
	
	@DataProvider(name = "LG_12")
	public static Object[][] modifiedRoleInCstar() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Login", "LG_12");
		return data;
	}
	
	@DataProvider(name = "TS_90")
	public static Object[][] noScreeningCode() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_90");
		return data;
	}
	
	@DataProvider(name = "TS_139")
	public static Object[][] requiredScreeningCode() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_139");
		return data;
	}
	@DataProvider(name = "TS_123")
	public static Object[][] searchingEmployeeWithEmptyValue() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_123");
		return data;
	}
	
	@DataProvider(name = "TS_126")
	public static Object[][] searchingEmployeeByTeam() {
		Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_126");
		return data;
	}
	@DataProvider(name = "TS_131")
    public static Object[][] ToCheckSearchExistEmployee() {
	    Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_131");
	    return data;
    }
	
	@DataProvider(name = "TS_132")
    public static Object[][] TS_132() {
	    Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_132");
	    return data;
    }
	@DataProvider(name = "TS_133")
    public static Object[][] TS_133() {
	    Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_133");
	    return data;
    }
	@DataProvider(name = "TS_134")
    public static Object[][] TS_134() {
	    Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_134");
	    return data;
    }
	@DataProvider(name = "TS_135")
    public static Object[][] TS_135() {
	    Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_135");
	    return data;
    }
	@DataProvider(name = "TS_136")
    public static Object[][] TS_136() {
	    Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_136");
	    return data;
    }
	@DataProvider(name = "TS_137")
    public static Object[][] TS_137() {
	    Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_137");
	    return data;
    }
	@DataProvider(name = "TS_138")
    public static Object[][] TS_138() {
	    Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet", "TS_138");
	    return data;
    }
	/**
     *Test data for Timesheet Approval
     *
     */
	@DataProvider(name = "TA_36")
    public static Object[][] searchByTechName() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet Approval", "TA_36");
        return data;
    }
	
    @DataProvider(name = "TA_37")
    public static Object[][] searchByScreeningCode() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet Approval", "TA_37");
        return data;
    }
    
    @DataProvider(name = "TA_38")
    public static Object[][] searchWithoutToSmtDate() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet Approval", "TA_38");
        return data;
    }
    
    @DataProvider(name = "TA_39")
    public static Object[][] searchWithoutFromSmtDate() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet Approval", "TA_39");
        return data;
    }
    
    @DataProvider(name = "TA_40")
    public static Object[][] searchWithBothSmtDate() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet Approval", "TA_40");
        return data;
    }
    
    @DataProvider(name = "TA_41")
    public static Object[][] searchByApprStatus() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet Approval", "TA_41");
        return data;
    }
    
    @DataProvider(name = "TA_52")
    public static Object[][] checkStatusOfBtnReject() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet Approval", "TA_52");
        return data;
    }
    
    @DataProvider(name = "TA_57")
    public static Object[][] rejectOneTimesheetSuccessful() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet Approval", "TA_57");
        return data;
    }

    
    /**
     *Test data for Timesheet History
     *
     */
    @DataProvider(name = "TH_18")
    public static Object[][] TH_18() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_18");
        return data;
    }
    @DataProvider(name = "TH_19")
    public static Object[][] TH_19() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_19");
        return data;
    }
    @DataProvider(name = "TH_20")
    public static Object[][] TH_20() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_20");
        return data;
    }
    @DataProvider(name = "TH_21")
    public static Object[][] TH_21() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_21");
        return data;
    }
    @DataProvider(name = "TH_22")
    public static Object[][] TH_22() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_22");
        return data;
    }
    @DataProvider(name = "TH_23")
    public static Object[][] TH_23() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_23");
        return data;
    }
    @DataProvider(name = "TH_24")
    public static Object[][] TH_24() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_24");
        return data;
    }
    @DataProvider(name = "TH_25")
    public static Object[][] TH_25() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_25");
        return data;
    }
    @DataProvider(name = "TH_26")
    public static Object[][] TH_26() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_26");
        return data;
    }
    @DataProvider(name = "TH_27")
    public static Object[][] TH_27() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_27");
        return data;
    }
    @DataProvider(name = "TH_28")
    public static Object[][] TH_28() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_28");
        return data;
    }
    @DataProvider(name = "TH_29")
    public static Object[][] TH_29() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_29");
        return data;
    }
    @DataProvider(name = "TH_30")
    public static Object[][] TH_30() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_30");
        return data;
    }
    @DataProvider(name = "TH_31")
    public static Object[][] TH_31() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_31");
        return data;
    }
    @DataProvider(name = "TH_32")
    public static Object[][] TH_32() {
        Object[][] data = ExcelHandle.getTable("./data/TestData.xlsx", "Timesheet History", "TH_32");
        return data;
    }
    
}
