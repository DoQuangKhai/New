package com.vsii.tcbs.testcase;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.vsii.tsc.model.TestCase;
import com.vsii.tsc.model.TestResult;
import com.vsii.tsc.utility.action.CommonOperations;
import com.vsii.tsc.utility.action.Synchronizer;
import com.vsii.tsc.utility.datetime.DateTime;
import com.vsii.tsc.utility.io.DownloadUploadFile;
import com.vsii.tsc.utility.io.ExcelHandle;
import com.vsii.tsc.utility.io.ReportHandle;

public class TestBase {
    public static WebDriver driver;
    public static Properties p;
    public static ExtentReports extent;
    public static ExtentTest test;
    public static FirefoxProfile fprofile;
    public static String methodName;
    public static String imageName;
    public static String testStatus;
    public RemoteWebDriver remoteDriver;
    DownloadUploadFile fileObj;
    public static boolean isGeneratedReport;
    public static String timeReport;
    public static ChromeDriverService chromeService;
    public String redmineUrl;
    public String redmineCredenfial;
    public String redmineProjectId;
    public static String fileOut;
    public String remoteUrl;
    public String browser;
    public String sheetName;
    private static TestResult objTestResult;
    private static List<TestResult> listResultStored;
    public static List<TestCase> tcListBase;

    @BeforeSuite
    public void cleanExcel(){
        //Create a list to store result (should in BeforeSuite in case multiple browser in ran at the same time)
        listResultStored = new ArrayList<TestResult>();
        tcListBase = new ArrayList<TestCase>();
    }
    
    @BeforeMethod
    @Parameters({ "remoteUrl", "browser", "redmineUrl", "redmineCredenfial", "redmineProjectId", "sheetName" })
    public void setupSuite(String remoteUrl, String browser, String redmineUrl, String redmineCredenfial,
      String redmineProjectId, String sheetName) throws IOException {
        // Define project id on Redmine
        this.redmineUrl = redmineUrl;
        this.redmineCredenfial = redmineCredenfial;
        this.redmineProjectId = redmineProjectId;
        this.sheetName=sheetName;
        this.browser=browser;
        this.remoteUrl=remoteUrl;

        // Read config file
        p = CommonOperations.readConfig();

        fileOut=p.getProperty("resultFile");

        // Run testscript with firefox browser
        if (browser.equalsIgnoreCase("firefox")) {
            System.out.println("You're running Firefox");

            // If remote string is empty, then script will run on local machine
            if (remoteUrl.isEmpty()) {
                driver = new FirefoxDriver();

            // Else script will run on remote machine
            } else {
                DesiredCapabilities firefoxCaps = DesiredCapabilities.firefox();
                driver = new RemoteWebDriver(new URL(remoteUrl), firefoxCaps);
            }

            // Run testscript with chrome browser
        } else if (browser.equalsIgnoreCase("chrome")) {
            System.out.println("You're running Chrome");

            // If remote string is empty, then script will run on local machine
            if (remoteUrl.isEmpty()) {
                System.setProperty(p.getProperty("chromeDriver"), p.getProperty("chromeDriverPath"));
                driver = new ChromeDriver();

                // Else script will run on remote machine
            } else {
                DesiredCapabilities chromeCaps = DesiredCapabilities.chrome();
                driver = new RemoteWebDriver(new URL(remoteUrl), chromeCaps);
            }

            // Run testscript with internet explorer browser
        } else if (browser.equalsIgnoreCase("ie")) {
            System.out.println("You're running IE");

            DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
            caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            caps.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
            caps.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);
            caps.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR, true);
            caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            caps.setJavascriptEnabled(true);

            // If remote string is empty, then script will run on local machine
            if (remoteUrl.isEmpty()) {
                System.setProperty(p.getProperty("ieDriver"), p.getProperty("ieDriverPath"));
                driver = new InternetExplorerDriver(caps);

                // Else script will run on remote machine
            } else {
                // WindowsUtils.writeIntRegistryValue("IE8RunOnceLastShown", 1);
                // WindowsUtils.writeIntRegistryValue("IE8RunOncePerInstallCompleted",
                // 1);
                // WindowsUtils.writeStringRegistryValue("IE8RunOnceCompletionTime",
                // "");
                // WindowsUtils.writeIntRegistryValue("IE8TourShown", 1);
                // WindowsUtils.writeStringRegistryValue("IE8TourShownTime",
                // "");
                // WindowsUtils.writeStringRegistryValue("IE8RunOnceLastShown",
                // "");
                driver = new RemoteWebDriver(new URL(remoteUrl), caps);
            }

            // Default run on firefox browser if browser parameter is not
            // defined
        } else {
            System.out.println("You're running Firefox");
            if (remoteUrl.isEmpty()) {
                driver = new FirefoxDriver();
            } else {
                DesiredCapabilities firefoxCaps = DesiredCapabilities.firefox();
                driver = new RemoteWebDriver(new URL(remoteUrl), firefoxCaps);
            }
        }

      // Setting browser window and timeout
      driver.manage().window().maximize();
      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      
        // Open base URL
      driver.get(p.getProperty("baseUrl"));
    }
    
    @AfterMethod
    public synchronized void getResultAndCaptureImage(ITestResult result) throws Exception
    {
        //Synchonize write result to an array list (in case test runner execute test in paralel mode)
        Synchronizer.getInstance().getTestResult(result, objTestResult, listResultStored, p);
        driver.quit();
    }
    
    @AfterClass
    public void closeBr(){
        driver.quit();
    }
    @AfterSuite
    public void writeTestResult()
    {
		timeReport = DateTime.createDateText("yyMMddHHmm");
		String resultFile = p.getProperty("resultpath")+p.getProperty("resultFile")+timeReport+".xlsx";
        //Copy testcase file to result file
        File source = new File(p.getProperty("tcFile"));
        File dest = new File(resultFile);
        ExcelHandle.copyFile(source, dest);
        
        //Write result to excel
        ExcelHandle.writeResultToExcel(listResultStored, resultFile);
        ReportHandle.buildHTMLReport(p.getProperty("reportFile")+timeReport+".html", tcListBase);
    }

}
