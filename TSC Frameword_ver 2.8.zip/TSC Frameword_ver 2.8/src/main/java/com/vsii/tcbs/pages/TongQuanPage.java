package com.vsii.tcbs.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TongQuanPage {
	//Giao dich navigation
	@FindBy(xpath = "//*[@id='sidebar-nav']/li[2]/a")
	private WebElement navGiaoDich;
	public WebElement getNavGiaoDich(){
		return navGiaoDich;
	}
	
	//Ten Tai khoan label
	@FindBy(xpath = "//*[@id='main-menu']/div/div[2]/div/div[1]/div[2]/h4")
	private WebElement lblTenTaiKhoan;
	public WebElement getLblTenTaiKhoan(){
		return lblTenTaiKhoan;
	}
	
	//Giao dich Quy dau tu button
	@FindBy(xpath = "html/body/div[2]/div/div/div/div[1]/div/div[3]/div[1]/div/div/div[1]/a")
	private WebElement btnGiaoDichQuyDauTu;
	public WebElement getBtnGiaoDichQuyDauTu(){
		return btnGiaoDichQuyDauTu;
	}
}
